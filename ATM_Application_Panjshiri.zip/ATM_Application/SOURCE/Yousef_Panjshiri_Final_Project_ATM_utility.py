#-------------------------------------------------------------------------------
# Final Project Application 
# Student Name: Yousef Panjshiri 
# Python version: 
# Submission Date: 12/06/2018
import datetime
def menu ():
   print('''What would you like to do today? 
         1. Withdraw Money
         2. Deposit Money
         3. Check Balance
         4. Fast Cash''')

def fast_cash (balance): #uses balance as a parameter 
   fast = 60
   if balance > fast :
      balance -= fast
      print ("$60 in your pocket baby")
      print ("Your current balance is", balance)
   else :
      print ("You don't have enough money in your account")#if your balance is less than fast cash value
   return balance #return balance to the calling function 
   
def deposit (balance): #balance as a parameter
   amount_dep = float(input("How much would you like to input: ")) #input amount
   while amount_dep <= 0: #cannot have negative money 
      amount_dep = float(input("That's Impossible bro! Enter again: "))
   balance += amount_dep #adds the input to the balance 
   print ("You deposited", amount_dep)
   print("Your current balance is,", balance)
   return balance #returns balance to the calling function 
   
def balance_account (balance):
   print("Your current balance is, ", balance)
   return balance #returns balance to the calling function 

def withdraw (balance):
   amount_drawn = float(input("How much would you like to take out: ")) #users input
   while amount_drawn > balance: #can't takeout more money that is in your account
      amount_drawn = float(input("you aren't as rich as you think, Enter again: "))#loops it to the input
   balance -= amount_drawn #subtracts the amount from the balance 
   print ("You withdrew", amount_drawn)
   print('Your remaining balance is', balance)
   return balance #returns balance to the calling function 

def write_account (account,pin,name,balance): #using the values from the main module 
   f = open('account_output.txt', 'w')#open output file 
   now = datetime.datetime.now() #date and time function 
   date = now.strftime('Date and Time: ' + '%Y-%m-%d %I:%M%p') #Formatting function to the Date and Time 
   f.write('Panjshiri Brothers Banking: Chantilly Branch\n') #Name of Branch 
   f.write(date +'\n') #Date
   f.write('Account no.: '+ account +'\n') #enters Account Number to output file
   f.write('Pin no.: '+ pin +'\n') #enters pin number to output file 
   f.write('Name: '+ name +'\n') #enters name to output file 
   f.write('Balance: '+ str(balance) +'\n') #enters the current_balance into the file 
   
   f.close () #close file 
