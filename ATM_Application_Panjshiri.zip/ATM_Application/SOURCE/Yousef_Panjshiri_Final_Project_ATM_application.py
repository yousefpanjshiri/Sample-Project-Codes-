#-------------------------------------------------------------------------------
# Final Project ATM application
# Student Name: Yousef Panjshiri
# Python version: 
# Submission Date: 12/06/2018
#-------------------------------------------------------------------
# Pseudocode:
#import utlility module
#open account file
#initialize empty dictionary
#store the values from the file into the dictionary
#assign values to balance,pin,name, and account to have global variables
#main function
    #Introduction to Panjshiri banking
    #initialize current_balance to equal balance
    #create a loop relating to the number of tries
        #state a variable equals true
        #input 4 digit pin
        #the input pin should equal the pin no. from the global dictionary
            #loop the options available if the pin is true
                #print menu
                #state the options and import from utilities.
                #set the function equal to to the curren_balance initialized in the beg. of main 
                #ask the user if they want to do another transaction
                #if Y
                    #then it loops back to the menu
                #else
                    #prints the current_balance
                    #exits the application
        #if the pin is not equal to the inputted pin from the user
            #the user has three tries
            #if the number of pin tries equals 0
                #then it prints they have to try in 24 hours 
#------------------------------------------------------------------------------------------------
import Yousef_Panjshiri_Final_Project_ATM_utility as y
f = open('account.txt', 'r') #opens file
lines = f.readlines() #reads lines 
account = {} #initializes empty dictionary
for line in lines: #loops lines 
    k,v = line.split(': ') #k and v are assigned to values in the dict
    account [(k.strip())] = v.strip() #strips the spaces
f.close () 
balance = float(account.get('Balance')) #converting string from dictionary to float
pin = account.get('Pin no.') #obtaining the string from the dictionary
name = account.get('Name')
account  = account.get('Account no.')
def main (): 
    print ("Hello welcome to Panjshiri Brothers Banking")
    print ("Insert your card to get started")
    current_balance = balance #used to update the balance from each option 
    tries = 3 #number of tries you have 
    while tries >= 0 : #three tries to guess right pin 
        contin = True #stating true for while condition 
        print (" ")
        pin_try = input("Enter your 4-digit pin: ") #enter pin
        print (" ")
        if pin_try == pin : #the string entered equals the pin from the dict 
            while(contin): #when this is true
                print("Hi", name,',')
                (y.menu())#menu 
                option = int(input("Enter your choice: ")) #option input
                if option == 1: #withdraw 
                    current_balance = y.withdraw(current_balance) #updating the balance through new variable 
                if option == 2: #deposit 
                    current_balance = y.deposit(current_balance) #updating balance through new variable
                if option == 3: #check balance 
                    current_balance = y.balance_account(current_balance) #just checks the balance 
                if option == 4: #fast cash 
                    current_balance = y.fast_cash(current_balance) #automatically withdraws 60$ from the balance
                print (" ")
                transaction = input("Would you like to do another transaction? (Y or N): ") #asks for another transaction 
                if transaction == 'Y' : #proceed 
                    contin = True #starts loop over again 
                else:
                    contin = False #stops the function
                    print (" ")
                    print ("Your current balance is, ", current_balance)
                    print (" ")
                    print ("Be sure to grab your card") 
                    print ("Thanks for banking with the Panjshiri Brothers", name)
                    
                    y.write_account(account,pin,name,current_balance)#writes the account info into the output file 
            break #breaks the code 
                                       
        elif pin != pin_try: #if pin from dict does not match with pin inputted by user 
            print("Wrong password: ") #wrong password is printed 
            tries -= 1 #3 tries
            if tries == 0: #when tries comes to zero 
                print ("Transaction cancelled, You must wait 24 hours to try again") 
                break #function is stopped

main () #call main 
    
        
            

